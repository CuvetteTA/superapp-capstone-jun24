import React from 'react'

const Browse = () => {
  return (
    <div>Browse</div>
  )
}

export default Browse