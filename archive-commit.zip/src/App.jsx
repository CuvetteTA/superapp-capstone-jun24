import React from "react";

const App = () => {
  return <div>React Application Running</div>;
};

export default App;
